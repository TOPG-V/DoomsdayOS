#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
[[ $(id -u) == 0 ]] || { echo 'Use sudo ./install.sh' >&2; exit 1; }
if [[ ${1:-} == --help ]]; then
  echo 'Usage: sudo ./install.sh [--no-apt]'
  echo 'Safe setup: creates a local recovery dataset, installs timers; never formats any drive.'
  exit 0
fi
[[ $# -eq 0 || ( $# -eq 1 && $1 == --no-apt ) ]] || { echo 'Unknown arguments' >&2; exit 2; }
command -v zfs >/dev/null || { echo 'ZFS tools not found' >&2; exit 1; }
[[ $(findmnt -n -o FSTYPE /) == zfs ]] || { echo 'This edition requires a ZFS root filesystem; no changes made.' >&2; exit 1; }
root_ds=$(findmnt -n -o SOURCE /)
root_pool=${root_ds%%/*}
[[ -n $root_pool && $root_pool != "$root_ds" ]] || { echo 'Unexpected root ZFS dataset; no changes made.' >&2; exit 1; }
zpool list -H "$root_pool" >/dev/null || { echo 'System pool missing; no changes made.' >&2; exit 1; }
boot_pool="$root_pool"
if [[ $(findmnt -M /boot -n -o FSTYPE 2>/dev/null || true) == zfs ]]; then
  boot_ds=$(findmnt -M /boot -n -o SOURCE)
  boot_pool=${boot_ds%%/*}
fi
if [[ ${1:-} != --no-apt ]]; then apt-get update && apt-get install -y --no-install-recommends zstd rsync zfs-auto-snapshot; fi
for bin in zstd rsync flock sha256sum; do command -v "$bin" >/dev/null || { echo "Missing dependency $bin" >&2; exit 1; }; done
install -d -m 0700 /etc/doomsday-vault
config=/etc/doomsday-vault/recovery.env
if [[ ! -e "$config" ]]; then
  {
    printf '# Doomsday Vault Recovery v2; system ZFS pool is autodetected at installation.\n'
    printf 'LOCAL_POOL=%q\nBOOT_POOL=%q\nLOCAL_DATASET=%q\n' "$root_pool" "$boot_pool" "$root_pool/DOOMSDAY_RECOVERY"
    printf 'LOCAL_DIR=/srv/doomsday-recovery\nBACKUP_SCOPES=auto\n'
    printf 'EXTERNAL_POOL=none\nEXTERNAL_GUID=\nEXTERNAL_DATASET=\nEXTERNAL_DIR=\n'
    printf 'KEEP_LOCAL=2\nKEEP_EXTERNAL=3\nMIN_FREE_GIB=20\nSYSTEM_COPIES=on\n'
  } > "$config"
else
  echo 'Existing root-owned recovery settings retained (V1 upgrade or V2 reinstall).'
fi
chown root:root "$config"
chmod 0600 "$config"
# Read existing config only after root-only ownership/mode has been enforced.
source "$config"
[[ "$LOCAL_POOL" == "$root_pool" ]] || { echo "Config system pool $LOCAL_POOL differs from detected $root_pool; refusing changes" >&2; exit 1; }
[[ "$LOCAL_DATASET" == "$root_pool/DOOMSDAY_RECOVERY" ]] || { echo 'Unexpected recovery dataset name; refusing changes' >&2; exit 1; }
[[ "$LOCAL_DIR" == /srv/doomsday-recovery ]] || { echo 'Unexpected local recovery mountpoint; refusing changes' >&2; exit 1; }
if ! zfs list -H "$LOCAL_DATASET" >/dev/null 2>&1; then
  zfs create -o mountpoint="$LOCAL_DIR" -o copies=2 -o com.sun:auto-snapshot=false "$LOCAL_DATASET"
fi
[[ $(zfs get -H -o value mountpoint "$LOCAL_DATASET") == "$LOCAL_DIR" ]] || { echo 'Local recovery dataset has unexpected mountpoint' >&2; exit 1; }
zfs set copies=2 "$LOCAL_DATASET"
zfs set com.sun:auto-snapshot=false "$LOCAL_DATASET"
zfs mount "$LOCAL_DATASET" 2>/dev/null || true
mountpoint -q "$LOCAL_DIR" || { echo 'Recovery dataset did not mount; stopping' >&2; exit 1; }
chmod 0700 "$LOCAL_DIR"
# Two copies of NEW system blocks, enabled by default; no changes to small boot pool.
if [[ ${SYSTEM_COPIES:-on} == on ]]; then
  zfs set copies=2 "$root_ds"
  if [[ $(findmnt -M /home -n -o FSTYPE 2>/dev/null || true) == zfs ]]; then
    home_ds=$(findmnt -M /home -n -o SOURCE)
    [[ "$home_ds" != "$root_ds" && "${home_ds%%/*}" == "$root_pool" ]] && zfs set copies=2 "$home_ds"
  fi
fi
install -d -m 0755 /usr/local/lib/doomsday-vault
for f in lib/*.sh; do install -m 0755 "$f" /usr/local/lib/doomsday-vault/; done
install -m 0755 enroll-external.sh /usr/local/lib/doomsday-vault/enroll-external.sh
for f in systemd/*; do install -m 0644 "$f" "/etc/systemd/system/$(basename "$f")"; done
systemctl daemon-reload
systemctl enable --now doomsday-backup.timer doomsday-external-sync.timer doomsday-verify.timer
if systemctl list-unit-files 'zfs-scrub-monthly@.timer' --no-legend 2>/dev/null | grep -q 'zfs-scrub-monthly@.timer'; then
  systemctl enable --now "zfs-scrub-monthly@${root_pool}.timer" || true
  [[ "$boot_pool" == "$root_pool" ]] || systemctl enable --now "zfs-scrub-monthly@${boot_pool}.timer" || true
fi
printf '\nInstalled for root pool %s and boot pool %s. No disks formatted.\n' "$root_pool" "$boot_pool"
echo 'To enroll ANY pre-existing external ZFS backup dataset:'
echo '  sudo /usr/local/lib/doomsday-vault/enroll-external.sh pool/dataset'
echo 'To check status: sudo /usr/local/lib/doomsday-vault/status.sh'
echo 'To run the first backup: sudo systemctl start doomsday-backup.service'
