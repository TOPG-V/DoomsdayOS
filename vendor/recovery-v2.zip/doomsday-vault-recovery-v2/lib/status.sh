#!/usr/bin/env bash
set -Eeuo pipefail
source /usr/local/lib/doomsday-vault/common.sh
printf '\nDoomsday Vault Recovery v2\n---------------------------\n'
printf 'System pool: %s | Boot pool: %s\n' "$LOCAL_POOL" "$BOOT_POOL"
zpool list -o name,size,alloc,free,health 2>/dev/null || true
printf '\nLocal recovery: %s\n' "$LOCAL_DIR"
completed_backups "$LOCAL_DIR" | head -5 || true
printf '\nExternal enrollment: %s (%s)\n' "$EXTERNAL_DATASET" "${EXTERNAL_GUID:-legacy/none}"
if [[ "$EXTERNAL_POOL" == none || -z "$EXTERNAL_DATASET" ]]; then
  echo 'Not enrolled: local-only operation'
else
  pool=$(find_external_pool) || pool=''
  if [[ -n "$pool" ]]; then
    echo "Found pool: $pool"
    if check_external_dir "$pool"; then completed_backups "$EXTERNAL_DIR" | head -5 || true; fi
  else echo 'Enrolled external pool disconnected/unavailable'; fi
fi
printf '\nAutomated service timers:\n'
systemctl list-timers --all --no-pager doomsday-backup.timer doomsday-external-sync.timer doomsday-verify.timer 2>/dev/null || true
