#!/usr/bin/env bash
set -Eeuo pipefail
source /usr/local/lib/doomsday-vault/common.sh
[[ $(id -u) == 0 ]] || fail 'Must run as root'
exec 9>/run/lock/doomsday-vault-backup.lock
flock -n 9 || { log 'Backup already running'; exit 0; }
check_backup_dir
pool_online "$LOCAL_POOL" || fail "System pool $LOCAL_POOL is not online"
[[ $(free_gib "$LOCAL_DATASET") -ge "$MIN_FREE_GIB" ]] || fail "Requires at least $MIN_FREE_GIB GiB free on $LOCAL_POOL"
mapfile -t scopes < <(list_source_datasets)
((${#scopes[@]})) || fail 'No ZFS filesystems selected for backup'
root_source=$(findmnt -n -o SOURCE /)
found_root=0
for ds in "${scopes[@]}"; do [[ "$ds" == "$root_source" ]] && found_root=1; done
((found_root)) || fail "Running root dataset $root_source is not in the backup set"
label="dv_$(date -u +%Y%m%dT%H%M%SZ)"
output="$LOCAL_DIR/backup-${label#dv_}"
[[ ! -e "$output" ]] || fail "Backup edition already exists $output"
tmpdir=$(mktemp -d "$LOCAL_DIR/.incomplete-XXXXXXXX")
cleanup() { [[ -z ${tmpdir:-} || ! -d "$tmpdir" ]] || rm -rf -- "$tmpdir"; }
trap cleanup EXIT
mkdir -m 0700 "$tmpdir/files"
printf 'dataset\tstream\tmode\n' > "$tmpdir/MANIFEST.tsv"
log "Snapshotting ${#scopes[@]} ZFS filesystems (not an application-consistent backup)"
for ds in "${scopes[@]}"; do zfs snapshot "$ds@$label"; done
for ds in "${scopes[@]}"; do
  key=$(printf '%s' "$ds" | sha256sum | awk '{print substr($1,1,24)}')
  file="files/${key}.zfs.zst"
  [[ ! -e "$tmpdir/$file" ]] || fail 'Snapshot archive filename collision'
  enc=$(zfs get -H -o value encryption "$ds" 2>/dev/null || echo off)
  mode=props
  if [[ "$enc" != off && "$enc" != - ]]; then
    mode=raw
    zfs send -w "$ds@$label" | zstd -q -1 -T1 -o "$tmpdir/$file.partial"
  else
    zfs send -p "$ds@$label" | zstd -q -1 -T1 -o "$tmpdir/$file.partial"
  fi
  mv "$tmpdir/$file.partial" "$tmpdir/$file"
  printf '%s\t%s\t%s\n' "$ds" "$file" "$mode" >> "$tmpdir/MANIFEST.tsv"
  log "Archived $ds"
done
if mountpoint -q /boot/efi && [[ -d /boot/efi/EFI ]]; then
  tar -C /boot/efi -cf "$tmpdir/EFI.tar" EFI
else
  log 'WARNING: EFI files not found at /boot/efi; disk-level recovery needs separate EFI backup'
fi
zfs list -o name,type,mountpoint,used,available > "$tmpdir/ZFS-LAYOUT.txt"
zpool status > "$tmpdir/ZPOOL-STATUS.txt"
lsblk -o NAME,SIZE,MODEL,SERIAL,TYPE,FSTYPE,MOUNTPOINTS > "$tmpdir/DRIVES.txt"
printf 'Version: 2\nUTC timestamp: %s\nRoot ZFS filesystem: %s\nSystem pool: %s\nBoot pool: %s\nData sets: %s\n' "${label#dv_}" "$root_source" "$LOCAL_POOL" "$BOOT_POOL" "${#scopes[@]}" > "$tmpdir/README-BACKUP.txt"
(cd "$tmpdir" && find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 -r sha256sum > SHA256SUMS && sha256sum -c --quiet SHA256SUMS)
mv "$tmpdir" "$output"
tmpdir=''
log "Verified local backup completed: $output"
# Sync before pruning so a connected second drive can retain an independent copy.
/usr/local/lib/doomsday-vault/sync-external.sh || log 'External sync skipped; local edition retained'
prune_backups "$LOCAL_DIR" "$KEEP_LOCAL"
# Keep only this tool's own snapshot series; never touch other snapshots.
for ds in "${scopes[@]}"; do
  count=0
  while IFS= read -r snapshot; do
    [[ -n "$snapshot" ]] || continue
    ((count+=1))
    if ((count>KEEP_LOCAL)); then zfs destroy "$snapshot" || log "Could not prune $snapshot"; fi
  done < <(zfs list -H -t snapshot -o name -r "$ds" | grep -E "^${ds//\//\\/}@dv_[0-9]{8}T[0-9]{6}Z$" | LC_ALL=C sort -r || true)
done
