#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
CONFIG=/etc/doomsday-vault/recovery.env
[[ -f "$CONFIG" ]] || { echo "Missing $CONFIG" >&2; exit 1; }
[[ $(stat -c %u "$CONFIG") == 0 && $(stat -c %a "$CONFIG") =~ ^(600|400)$ ]] || { echo "Unsafe config ownership/mode: $CONFIG" >&2; exit 1; }
# A root-only configuration file; do not accept configuration from LAN clients.
# shellcheck source=/dev/null
source "$CONFIG"
BOOT_POOL=${BOOT_POOL:-auto}
if [[ "$BOOT_POOL" == auto ]]; then
  if [[ $(findmnt -M /boot -n -o FSTYPE 2>/dev/null || true) == zfs ]]; then
    boot_source=$(findmnt -M /boot -n -o SOURCE)
    BOOT_POOL=${boot_source%%/*}
  else
    BOOT_POOL=$LOCAL_POOL
  fi
fi
BACKUP_SCOPES=${BACKUP_SCOPES:-auto}
EXTERNAL_POOL=${EXTERNAL_POOL:-none}
EXTERNAL_GUID=${EXTERNAL_GUID:-}
EXTERNAL_DATASET=${EXTERNAL_DATASET:-}
EXTERNAL_DIR=${EXTERNAL_DIR:-}
if [[ -z "$EXTERNAL_DATASET" && "$EXTERNAL_POOL" != none && "$EXTERNAL_DIR" == "/$EXTERNAL_POOL/backups/doomsday-os" ]]; then
  EXTERNAL_DATASET="$EXTERNAL_POOL/backups"
fi
KEEP_LOCAL=${KEEP_LOCAL:-2}
KEEP_EXTERNAL=${KEEP_EXTERNAL:-3}
MIN_FREE_GIB=${MIN_FREE_GIB:-20}
SYSTEM_COPIES=${SYSTEM_COPIES:-off}
log() { printf '[doomsday] %s\n' "$*"; }
fail() { log "ERROR: $*" >&2; exit 1; }
pool_online() { zpool list -H -o health "$1" 2>/dev/null | grep -Eq '^(ONLINE|DEGRADED)$'; }
check_backup_dir() {
  [[ -d "$LOCAL_DIR" ]] || fail "Missing local backup directory: $LOCAL_DIR"
  mountpoint -q "$LOCAL_DIR" || fail "Local backup dataset is not mounted: $LOCAL_DIR"
  [[ $(zfs get -H -o value mountpoint "$LOCAL_DATASET") == "$LOCAL_DIR" ]] || fail 'Unexpected recovery dataset mountpoint'
}
free_gib() { zfs get -H -p -o value available "$1" | awk '{printf "%d", $1/1073741824}'; }
completed_backups() {
  local dir=$1
  [[ -d "$dir" ]] || return 0
  find "$dir" -mindepth 1 -maxdepth 1 -type d -name 'backup-*' -printf '%f\n' | LC_ALL=C sort -r
}
prune_backups() {
  local dir=$1 keep=$2 name count=0
  [[ "$keep" =~ ^[1-9][0-9]*$ ]] || fail 'Invalid retention count'
  while IFS= read -r name; do
    [[ "$name" =~ ^backup-[0-9]{8}T[0-9]{6}Z$ ]] || continue
    ((count+=1))
    if ((count>keep)); then log "Deleting older completed edition $dir/$name"; rm -rf -- "$dir/$name"; fi
  done < <(completed_backups "$dir")
}
# Supports any ZFS system pool name. On v1 configs, BOOT_POOL=auto detects /boot.
source_pool() {
  local mp=$1 src fs
  fs=$(findmnt -M "$mp" -n -o FSTYPE 2>/dev/null || true)
  [[ "$fs" == zfs ]] || return 1
  src=$(findmnt -M "$mp" -n -o SOURCE)
  printf '%s\n' "${src%%/*}"
}
list_source_datasets() {
  local scope name pool
  if [[ "$BACKUP_SCOPES" == auto ]]; then
    for pool in "$LOCAL_POOL" "$BOOT_POOL"; do
      [[ "$pool" != auto && -n "$pool" && "$pool" != none ]] || continue
      zfs list -H -o name -t filesystem -r "$pool" 2>/dev/null || true
    done
  else
    for scope in $BACKUP_SCOPES; do
      pool=${scope%%/*}
      [[ "$pool" == "$LOCAL_POOL" || "$pool" == "$BOOT_POOL" ]] || fail "Unapproved source pool: $pool"
      zfs list -H -o name -t filesystem -r "$scope" 2>/dev/null || log "Missing optional source: $scope"
    done
  fi | LC_ALL=C sort -u | while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    [[ "$name" == "$LOCAL_DATASET" || "$name" == "$LOCAL_DATASET/"* ]] && continue
    [[ "$name" == "$LOCAL_POOL" || "$name" == "$LOCAL_POOL/"* || "$name" == "$BOOT_POOL" || "$name" == "$BOOT_POOL/"* ]] || continue
    printf '%s\n' "$name"
  done
}
# Only a previously enrolled pool can be imported. Never force import.
find_external_pool() {
  local name guid
  [[ -n "$EXTERNAL_DATASET" && "$EXTERNAL_POOL" != none ]] || return 1
  if [[ -n "$EXTERNAL_GUID" ]]; then
    name=$(zpool list -H -o name,guid 2>/dev/null | awk -v g="$EXTERNAL_GUID" '$2==g {print $1; exit}' || true)
    [[ -n "$name" ]] && { printf '%s\n' "$name"; return 0; }
    [[ -d /dev/disk/by-id ]] && zpool import -N -d /dev/disk/by-id "$EXTERNAL_GUID" >/dev/null 2>&1 || true
    name=$(zpool list -H -o name,guid 2>/dev/null | awk -v g="$EXTERNAL_GUID" '$2==g {print $1; exit}' || true)
    [[ -n "$name" ]] || return 1
    printf '%s\n' "$name"
  else
    # Legacy v1: allow the explicitly configured pool name, never an arbitrary disk.
    if ! pool_online "$EXTERNAL_POOL"; then
      [[ -d /dev/disk/by-id ]] && zpool import -N -d /dev/disk/by-id "$EXTERNAL_POOL" >/dev/null 2>&1 || true
    fi
    pool_online "$EXTERNAL_POOL" || return 1
    printf '%s\n' "$EXTERNAL_POOL"
  fi
}
check_external_dir() {
  local pool=$1 actual_mount
  [[ "$pool" != "$LOCAL_POOL" && "$pool" != "$BOOT_POOL" ]] || fail 'External backup pool cannot be a system pool'
  [[ "$EXTERNAL_DATASET" == "$pool/"* ]] || fail "External dataset $EXTERNAL_DATASET does not belong to $pool"
  [[ $(zfs list -H -o type "$EXTERNAL_DATASET" 2>/dev/null) == filesystem ]] || fail 'Enrolled ZFS filesystem missing'
  actual_mount=$(zfs get -H -o value mountpoint "$EXTERNAL_DATASET")
  [[ "$actual_mount" == /* && "$actual_mount" != / ]] || fail 'Unsafe backup dataset mountpoint'
  [[ "$EXTERNAL_DIR" == "$actual_mount/doomsday-os" ]] || fail 'Backup path not inside enrolled dataset'
  mountpoint -q "$actual_mount" || zfs mount "$EXTERNAL_DATASET" >/dev/null 2>&1 || true
  mountpoint -q "$actual_mount" || fail 'Enrolled backup dataset is not mounted'
  [[ -d "$EXTERNAL_DIR" ]] || mkdir -m 0700 "$EXTERNAL_DIR"
  chmod 0700 "$EXTERNAL_DIR"
}
