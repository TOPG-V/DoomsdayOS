#!/usr/bin/env bash
set -Eeuo pipefail
source /usr/local/lib/doomsday-vault/common.sh
[[ $(id -u) == 0 ]] || fail 'Must run as root'
exec 8>/run/lock/doomsday-vault-external.lock
flock -n 8 || { log 'External sync already running'; exit 0; }
if [[ "$EXTERNAL_POOL" == none || -z "$EXTERNAL_DATASET" ]]; then log 'No backup drive enrolled; local-only mode'; exit 0; fi
pool=$(find_external_pool) || { log 'Enrolled backup pool not present; local-only mode'; exit 0; }
check_external_dir "$pool"
check_backup_dir
while IFS= read -r name; do
  [[ "$name" =~ ^backup-[0-9]{8}T[0-9]{6}Z$ ]] || continue
  src="$LOCAL_DIR/$name"
  dest="$EXTERNAL_DIR/$name"
  [[ -f "$src/SHA256SUMS" ]] || continue
  if [[ -d "$dest" ]]; then
    if (cd "$dest" && sha256sum -c --quiet SHA256SUMS); then continue; fi
    fail "Existing external edition $dest FAILED integrity; refusing overwrite"
  fi
  pending="$EXTERNAL_DIR/.incomplete-$name"
  mkdir -p "$pending"
  log "Syncing $name to enrolled ZFS pool $pool"
  rsync -a --partial "$src/" "$pending/"
  (cd "$pending" && sha256sum -c --quiet SHA256SUMS) || fail 'External checksum check failed'
  [[ ! -e "$dest" ]] || fail "Destination unexpectedly exists: $dest"
  mv "$pending" "$dest"
  log "Verified external backup: $dest"
done < <(completed_backups "$LOCAL_DIR" | LC_ALL=C sort)
prune_backups "$EXTERNAL_DIR" "$KEEP_EXTERNAL"
