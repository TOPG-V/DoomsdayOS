#!/usr/bin/env bash
set -Eeuo pipefail
source /usr/local/lib/doomsday-vault/common.sh
[[ $(id -u) == 0 ]] || fail 'Must run as root'
check_backup_dir
result=0
while IFS= read -r name; do
  [[ "$name" =~ ^backup-[0-9]{8}T[0-9]{6}Z$ ]] || continue
  if (cd "$LOCAL_DIR/$name" && sha256sum -c --quiet SHA256SUMS); then
    log "PASS local: $name"
  else
    log "FAIL local: $name (no automatic system rollback)"
    result=1
  fi
done < <(completed_backups "$LOCAL_DIR")
if [[ "$EXTERNAL_POOL" != none && -n "$EXTERNAL_DATASET" ]]; then
  pool=$(find_external_pool) || pool=''
  if [[ -n "$pool" ]] && check_external_dir "$pool"; then
    while IFS= read -r name; do
      [[ "$name" =~ ^backup-[0-9]{8}T[0-9]{6}Z$ ]] || continue
      if (cd "$EXTERNAL_DIR/$name" && sha256sum -c --quiet SHA256SUMS); then
        log "PASS external: $name"
      else
        log "FAIL external: $name (requires manual restoration)"
        result=1
      fi
    done < <(completed_backups "$EXTERNAL_DIR")
  fi
fi
exit "$result"
