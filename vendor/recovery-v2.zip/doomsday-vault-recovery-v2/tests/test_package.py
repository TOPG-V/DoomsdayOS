"""Static and mocked tests. Never touch a real ZFS pool or a physical drive."""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class TestRecoveryPackage(unittest.TestCase):
    def test_all_shell_scripts_parse(self):
        for shell in [ROOT / 'install.sh', ROOT / 'enroll-external.sh', *(ROOT / 'lib').glob('*.sh')]:
            with self.subTest(file=shell.name):
                subprocess.run(['bash', '-n', str(shell)], check=True)

    def test_no_hardware_model_or_device_assumptions(self):
        scripts = '\n'.join(p.read_text() for p in [ROOT / 'install.sh', ROOT / 'enroll-external.sh', *(ROOT / 'lib').glob('*.sh')])
        for forbidden in ('ST1000LM035', 'Hitachi', 'Seagate', '/dev/sdb', '/dev/sda', 'wwn-0x'):
            self.assertNotIn(forbidden, scripts)

    def test_no_format_or_destructive_pool_management(self):
        scripts = '\n'.join(p.read_text() for p in [ROOT / 'install.sh', ROOT / 'enroll-external.sh', *(ROOT / 'lib').glob('*.sh')])
        for forbidden in ('zpool create', 'zpool destroy', 'wipefs ', 'mkfs.', 'zfs receive -F', 'zpool import -f'):
            self.assertNotIn(forbidden, scripts)
        self.assertIn('zpool import -N -d /dev/disk/by-id', scripts)

    def test_files_and_retention_timers_present(self):
        for file in ['LICENSE', 'config.env', 'README.md', 'install.sh', 'enroll-external.sh']:
            self.assertTrue((ROOT/file).is_file())
        for unit in ['doomsday-backup.service', 'doomsday-backup.timer', 'doomsday-external-sync.service', 'doomsday-external-sync.timer', 'doomsday-verify.service', 'doomsday-verify.timer']:
            self.assertTrue((ROOT/'systemd'/unit).exists())

    def test_backup_index_checksums_and_efi(self):
        backup = (ROOT/'lib/backup.sh').read_text()
        self.assertIn('zfs send -p', backup)
        self.assertIn('zfs send -w', backup)
        self.assertIn('EFI.tar', backup)
        self.assertIn('SHA256SUMS', backup)
        self.assertIn('sha256sum -c --quiet', backup)
        self.assertIn('list_source_datasets', backup)
        self.assertIn('check_backup_dir', backup)
        self.assertIn('LOCAL_DATASET', backup)

    def test_sync_requires_explicit_enrollment(self):
        sync=(ROOT/'lib/sync-external.sh').read_text()
        self.assertIn('EXTERNAL_POOL" == none', sync)
        self.assertIn('find_external_pool', sync)
        self.assertIn('check_external_dir', sync)
        self.assertIn('rsync -a --partial', sync)
        self.assertIn('sha256sum -c --quiet', sync)

    def _mocked_shell(self, code: str, cfg: dict[str, str]) -> str:
        with tempfile.TemporaryDirectory() as temp:
            directory=Path(temp)
            config=directory/'config.env'
            config.write_text(''.join(f'{k}={v}\n' for k,v in cfg.items()))
            config.chmod(0o600)
            script=directory/'common.sh'
            script.write_text((ROOT/'lib/common.sh').read_text().replace('CONFIG=/etc/doomsday-vault/recovery.env', f'CONFIG={config}'))
            script.chmod(0o700)
            binfolder=directory/'bin'
            binfolder.mkdir()
            # A deterministic fake ZFS CLI, not a real disk.
            zfs=binfolder/'zfs'
            zfs.write_text('''#!/bin/bash
if [[ "$1" == list ]]; then
  pool="${@: -1}"
  case "$pool" in
    osmirror) printf '%s\\n' osmirror osmirror/ROOT osmirror/ROOT/ubuntu osmirror/USERDATA osmirror/DOOMSDAY_RECOVERY osmirror/DOOMSDAY_RECOVERY/special;;
    tinyboot) printf '%s\\n' tinyboot tinyboot/BOOT tinyboot/BOOT/ubuntu;;
  esac
fi
''')
            zfs.chmod(0o755)
            zpool=binfolder/'zpool'
            zpool.write_text('#!/bin/bash\nif [[ "$1" == list ]]; then printf "%s\\n" "mybackup 123456"; fi\n')
            zpool.chmod(0o755)
            env=dict(os.environ, PATH=str(binfolder)+':'+os.environ['PATH'])
            proc=subprocess.run(['bash','-c',f'source {script}; {code}'],capture_output=True,text=True,env=env)
            if proc.returncode:
                raise AssertionError(f'Fake-ZFS test failed: {proc.stderr}')
            return proc.stdout

    def test_auto_scopes_detect_custom_system_and_boot_pool_names(self):
        cfg={'LOCAL_POOL':'osmirror', 'BOOT_POOL':'tinyboot', 'LOCAL_DATASET':'osmirror/DOOMSDAY_RECOVERY', 'LOCAL_DIR':'/srv/doomsday-recovery', 'BACKUP_SCOPES':'auto', 'EXTERNAL_POOL':'none'}
        results=self._mocked_shell('list_source_datasets',cfg).splitlines()
        self.assertIn('osmirror/ROOT/ubuntu',results)
        self.assertIn('osmirror/USERDATA',results)
        self.assertIn('tinyboot/BOOT/ubuntu',results)
        self.assertNotIn('osmirror/DOOMSDAY_RECOVERY',results)
        self.assertNotIn('osmirror/DOOMSDAY_RECOVERY/special',results)

    def test_external_drive_lookup_by_pool_guid(self):
        cfg={'LOCAL_POOL':'osmirror', 'BOOT_POOL':'tinyboot', 'LOCAL_DATASET':'osmirror/DOOMSDAY_RECOVERY', 'LOCAL_DIR':'/srv/doomsday-recovery', 'EXTERNAL_POOL':'mybackup', 'EXTERNAL_GUID':'123456', 'EXTERNAL_DATASET':'mybackup/recovery', 'EXTERNAL_DIR':'/mnt/mybackup/recovery/doomsday-os'}
        found=self._mocked_shell('find_external_pool',cfg).strip()
        self.assertEqual(found,'mybackup')

    def test_missing_external_remains_local_only(self):
        cfg={'LOCAL_POOL':'osmirror', 'BOOT_POOL':'tinyboot', 'LOCAL_DATASET':'osmirror/DOOMSDAY_RECOVERY', 'LOCAL_DIR':'/srv/doomsday-recovery', 'EXTERNAL_POOL':'none', 'EXTERNAL_DATASET':''}
        out=self._mocked_shell('if find_external_pool; then echo UNEXPECTED; else echo LOCAL_ONLY; fi',cfg)
        self.assertEqual(out.strip(),'LOCAL_ONLY')


if __name__=='__main__':
    unittest.main()
