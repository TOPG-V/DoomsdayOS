#!/usr/bin/env bash
set -Eeuo pipefail
[[ $(id -u) == 0 ]] || { echo 'Run as root: sudo ./enroll-external.sh pool/backup-dataset' >&2; exit 1; }
[[ $# -eq 1 ]] || { echo 'Usage: sudo ./enroll-external.sh pool/dataset' >&2; exit 2; }
source /usr/local/lib/doomsday-vault/common.sh
selected=$1
[[ "$selected" =~ ^[A-Za-z0-9_.:-]+(/[A-Za-z0-9_.:-]+)+$ ]] || fail 'Expected a safe ZFS dataset name, e.g. vault-backups/recovery'
pool=${selected%%/*}
[[ "$pool" != "$LOCAL_POOL" && "$pool" != "$BOOT_POOL" ]] || fail 'Cannot enroll a system ZFS pool as an independent backup'
pool_online "$pool" || fail "Pool $pool must already be imported and healthy. Nothing formatted."
[[ $(zfs list -H -o type "$selected" 2>/dev/null) == filesystem ]] || fail 'Dataset must already exist and be a ZFS filesystem'
mp=$(zfs get -H -o value mountpoint "$selected")
[[ "$mp" == /* && "$mp" != / && "$mp" != /srv/doomsday-recovery ]] || fail 'Unsafe dataset mountpoint'
mountpoint -q "$mp" || fail "Please mount $selected at $mp first"
guid=$(zpool get -H -o value guid "$pool")
[[ "$guid" =~ ^[0-9]+$ ]] || fail 'Could not verify numeric pool GUID'
mkdir -m 0700 -p "$mp/doomsday-os"
chmod 0700 "$mp/doomsday-os"
config=/etc/doomsday-vault/recovery.env
new=$(mktemp /etc/doomsday-vault/.recovery-env-XXXXXX)
chmod 0600 "$new"
awk -F= '$1!="EXTERNAL_POOL" && $1!="EXTERNAL_GUID" && $1!="EXTERNAL_DATASET" && $1!="EXTERNAL_DIR"' "$config" > "$new"
{
  printf 'EXTERNAL_POOL=%q\n' "$pool"
  printf 'EXTERNAL_GUID=%q\n' "$guid"
  printf 'EXTERNAL_DATASET=%q\n' "$selected"
  printf 'EXTERNAL_DIR=%q\n' "$mp/doomsday-os"
} >> "$new"
chown root:root "$new"
mv -f "$new" "$config"
log "Enrolled $selected (ZFS pool GUID $guid); does not depend on USB device name or disk vendor"
log 'IMPORTANT: Verify this backup pool is physically on a separate drive.'
log 'No drives were formatted or repartitioned.'
