# Doomsday Vault Recovery V2 — hardware-independent ZFS recovery

A reusable, source-available set of Bash/systemd scripts for **ZFS-root Linux** installations. It is not tied to Hitachi, Seagate, USB port numbers, disk models, drive sizes, hostname, or the Linux `/dev/sdX` order.

**This ZIP is a recovery component for a future custom installer/ISO, not an ISO itself.** The code is covered by the MIT license in `LICENSE`. OpenZFS, Ubuntu, and bundled third-party dependencies retain their own licenses.

## How it works

### One ZFS drive connected

- Detects the **actual mounted ZFS root pool** using `findmnt /`, rather than assuming `rpool`.
- Detects a separate `/boot` ZFS pool, if present, rather than assuming `bpool`.
- Creates the local recovery dataset `SYSTEMPOOL/DOOMSDAY_RECOVERY` at `/srv/doomsday-recovery` (without touching existing pools or partitions).
- Saves two independently checkable weekly full ZFS stream archives **on the same system pool**, plus EFI bootloader files when `/boot/efi` is mounted.
- Enables `copies=2` for *future writes* to the recovery dataset and (by default) the current root and any separate `/home` dataset. This doubles physical block usage in affected datasets before compression and may reduce usable capacity. `copies=2` does **not** retroactively duplicate existing blocks and cannot repair a dead drive.
- Maintains periodic SHA-256 archive verification and ZFS scrubs (where Ubuntu supplies monthly scrub timers).

### An additional ZFS drive is connected

- You **enroll one existing ZFS filesystem**, for example `tank/backups` or `western-digital/recovery`, by running the enrollment script once as root.
- The script records the **ZFS pool GUID**, which is independent of USB port, SATA port, enclosure model, and `/dev/sdX` numbering.
- When the enrolled pool is available, periodic sync copies completed backup editions into `<dataset-mountpoint>/doomsday-os` and verifies their SHA-256 manifest.
- When the drive is disconnected, local backups continue. Reconnected exported pools can be re-imported without `-f` using the enrolled GUID and `/dev/disk/by-id` discovery. The service never force-imports a potentially active disk.
- The second pool can be on a **Toshiba, WD, Seagate, Hitachi, Samsung, Kingston, or other drive**. A filesystem does not have to be named `tank`.
- This is **not** a disk-imaging utility: it does not format, partition, or initialize an external drive. It only writes into the ZFS filesystem you explicitly enroll.

### Important limits

- A local copy, a snapshot and `copies=2` do **not** survive complete drive failure. For true disaster recovery, use another physically independent drive and periodically test restoration.
- A second *pool* does not necessarily mean another *physical drive*; confirm the topology yourself with `lsblk` and `zpool status`.
- The backup consists of individually stored ZFS streams, EFI files, a disk inventory, and a checksum manifest. **A full bare-metal restore requires a Linux rescue environment, recreation of partitions, ZFS receiving, bootloader setup, and a tested restore procedure.** No automatic overwrite/rollback of your live OS occurs.
- Running live filesystem snapshots is **not application-consistent** for open databases or virtual machines. Stop critical services or take an application-level backup first.
- ZFS encryption keys are not automatically escrowed; keep your decryption keys safely elsewhere. Encrypted datasets are transmitted as raw encrypted streams when supported.
- Backups are space-intensive. With two local editions and copies=2, a nearly full system may run out of space; monitor disk usage and adjust retention.
- The package does not back up data stored exclusively on the external ZFS pool itself (e.g. a very large ZIM collection). For that, arrange a third independent backup or copy important ZIMs to another healthy filesystem.
- It has not been run against your physical Ubuntu system by the author. Test one backup and a non-destructive restore before relying on it.

## Ubuntu installation — single-line commands

Download `doomsday-vault-recovery-v2.zip` to your Ubuntu **Downloads** folder.

1. Unpack: `cd ~/Downloads && unzip doomsday-vault-recovery-v2.zip`
2. Enter folder: `cd ~/Downloads/doomsday-vault-recovery-v2`
3. Install: `sudo ./install.sh`
4. Check status: `sudo /usr/local/lib/doomsday-vault/status.sh`
5. Start first full backup: `sudo systemctl start doomsday-backup.service`
6. Check logs: `sudo journalctl -u doomsday-backup.service -n 70 --no-pager`
7. Verify copies: `sudo /usr/local/lib/doomsday-vault/verify.sh`

Every command is **one line**. Your `sudo` password must be typed at the prompt; Linux intentionally displays no password characters.

If the scripts' dependencies are already preinstalled (such as in a custom ISO), use `sudo ./install.sh --no-apt` instead of step 3.

### Enroll ANY existing external ZFS filesystem

Example with an already-created `tank/backups` dataset:

1. Verify which pool owns the backup dataset: `sudo zfs list -o name,mountpoint -t filesystem`
2. Enroll: `sudo /usr/local/lib/doomsday-vault/enroll-external.sh tank/backups`
3. Test sync: `sudo systemctl start doomsday-external-sync.service`
4. Show status: `sudo /usr/local/lib/doomsday-vault/status.sh`

For a completely different disk with a dataset named `mybackup/recovery`, replace `tank/backups` with `mybackup/recovery`. **Don't call `zpool create`, `wipefs`, `mkfs`, or `zpool destroy`** for this setup. The backup filesystem must already exist, be imported, and be mounted.

**No backup drive?** Skip enrollment. Local-only mode still works and won't fail just because another drive is missing.

**Want to switch backup drives?** Prepare/import a ZFS filesystem on the new disk, then enroll it by its actual `pool/dataset` name. This changes only the saved external destination, not the system pool. Existing backup files on the old disk stay there.

### Control redundancy, space, and retention

The root-only configuration is at `/etc/doomsday-vault/recovery.env`.

- `SYSTEM_COPIES=on` enables double copies for future writes to root and separate `/home` datasets during install. Set `off` **before running install** if your root pool is too small. Existing `copies=2` ZFS properties must be changed explicitly with `zfs set copies=1` if you want to undo them.
- `KEEP_LOCAL=2`: number of complete local backup editions retained.
- `KEEP_EXTERNAL=3`: number of complete external editions retained.
- `MIN_FREE_GIB=20`: refuse to start a backup below this free-space threshold.
- `BACKUP_SCOPES=auto`: enumerate all ZFS filesystem datasets under the detected system and separate boot pools, excluding the local recovery dataset. The old V1 config may have its own scopes, which remain respected.

A second run of `sudo ./install.sh` retains the existing root-owned config and doesn't recreate a pool. The installer refuses to proceed if the saved system-pool identity conflicts with the running installation.

### Timers and integrity

- `doomsday-backup.timer`: weekly complete ZFS archives.
- `doomsday-external-sync.timer`: every 10 minutes after startup while the OS is running; if no enrolled target is present, silently stays local-only.
- `doomsday-verify.timer`: monthly manifest verification.
- Ubuntu `zfs-scrub-monthly@POOL.timer` (when packaged): monthly block checksum scans for detected system and boot pools.

`copies=2` enables OpenZFS to repair some corrupted data blocks from another intact copy; it does not promise recovery from every corruption event. The script **detects** archive checksum failures but does not automatically replace a known-bad backup or overwrite the running operating system.

### How a future open-source ISO should use this

1. Install Linux with a **ZFS root** and ensure tools like `zfs`, `zpool`, `zstd`, `rsync`, and `systemd` are available.
2. Bundle the V2 recovery directory inside the installer image.
3. After the OS boots for the first time, run `sudo ./install.sh --no-apt` as a one-time bootstrap action; it auto-detects the installed pools.
4. Optionally offer the user a UI for enrolling an external **already-formatted ZFS** backup dataset.
5. Never embed the creator's pool GUIDs, USB serial numbers, user passwords, private backup archives, or ZIM data unless the ZIM archive's redistributable license explicitly allows it.
6. Test boot, snapshot, full-backup verification, and a restore in a separate VM before releasing an installer.

The current package deliberately does **not** bundle, build, or modify an ISO. The network search engine / Kiwix service is a separate layer.

## Upgrading from V1

The installer preserves an existing `/etc/doomsday-vault/recovery.env` with its `rpool`/`bpool` settings if those match the actual running system. V2's code can read legacy `EXTERNAL_POOL=tank` and `/tank/backups/doomsday-os`, but enrolling `tank/backups` explicitly is recommended to store its stable pool GUID.

Run `sudo ./install.sh` from the V2 folder, then `sudo /usr/local/lib/doomsday-vault/enroll-external.sh tank/backups` if that ZFS dataset exists and is mounted. V1 backup archives remain in place.

## Restoring (deliberately manual)

Verify archives with `sudo /usr/local/lib/doomsday-vault/verify.sh`. You can inspect `MANIFEST.tsv` and `SHA256SUMS` in each `backup-*` directory. ZFS streams can be decompressed and received into an appropriately prepared recovery pool, for example from a live/rescue USB, but do **not** execute a `zfs receive -F` against the running system. It can destroy target filesystem data. Follow a tested disaster-recovery playbook using a separate spare drive and protect EFI and encryption credentials.

## Safety tests

`python3 -m unittest discover -s tests -v`

The tests check package layout, safety properties, shell syntax, and generic-drive enrollment logic using mocked ZFS commands. They do **not** replace real hardware/restore validation.
